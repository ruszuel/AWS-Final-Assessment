import json

def handler(event, context):
    print("card-transaction invoked")

    return {
        'statusCode': 200,
        'body': "Card Transaction Invoked"
    }