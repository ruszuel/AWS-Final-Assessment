import json

def handler(event, context):
    print("card-transaction process invoked")

    return {
        'statusCode': 200,
        'body': "Card Transaction PRocess Invoked"
    }